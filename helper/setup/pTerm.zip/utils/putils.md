---
description: >-
  This page describes what the package "putils" is, what it does and how you can
  use it to make beautiful TUIs even faster!
---

# PTerm Utils Package (putils)

{% hint style="warning" %}
This page is work in progress!
{% endhint %}
